import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;

public class ServeurUdpEcho {

	/**
	 * @param args
	 * @throws IOException
	 */

	int port;
	int nbClients;

	public ServeurUdpEcho(int port, int nbClients){
		this.port = port;
		this.nbClients = nbClients;
	}

	public void lancer() {
		byte[] buf = new byte[256];

		String chaineEnvoyé;

		try {
			DatagramSocket socket = new DatagramSocket(port);

			DatagramPacket paquetReceive = new DatagramPacket(buf, buf.length);

			DatagramPacket paquetSend;

			while (true) {
				// Le serveur se bloque sur receive jusqu'à ce qu'il reçoive un
				// message d'un client.

				socket.receive(paquetReceive);

				// il réccupère la chaine EXACTE envoyée par le client (en ignorant les octets qui ne correspondent pas à cette chaine) 
				chaineEnvoyé = new String(paquetReceive.getData(), 0,
						paquetReceive.getLength()).toUpperCase();

				paquetSend = new DatagramPacket(chaineEnvoyé.getBytes(),
						chaineEnvoyé.length(), paquetReceive.getSocketAddress());

				// Pour éviter de créer à chaque itération un nouvel objet
				// DatagramPaquet avec le new, on peut utiliser un seul objet
				// et on modifie à chaque itérations ses attributs comme suite :

				// *** On met à jour les données de paquetSend
				// paquetSend.setData(chaineEnvoyé.getBytes());
				// *** la taille est automatiquement mise à jour avec
				// *** setData
				//
				// *** On met à jour l'IP et le port du destinataire (client)
				// paquetSend.setSocketAddress(paquetReceive.getSocketAddress());
				//
				// On peut aussi utiliser un seul paquet pour l'envoi et pour la reception come le montre le serveur udp echo bis

				// On envoie le paquet
				socket.send(paquetSend);

			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		new ServeurUdpEcho( 50007,5).lancer();
	}

}