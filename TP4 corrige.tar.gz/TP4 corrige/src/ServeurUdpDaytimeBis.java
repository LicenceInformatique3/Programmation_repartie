import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.GregorianCalendar;

public class ServeurUdpDaytimeBis {

	int port;
	int nbClients;

	public ServeurUdpDaytimeBis(int port, int nbClients) {
		this.port = port;
		this.nbClients = nbClients;
	}

	public void lancer() throws IOException {
		DatagramSocket serveur = new DatagramSocket(port);

		byte[] buf = new byte[50];
		DatagramPacket paquet = new DatagramPacket(buf, buf.length);

		serveur.receive(paquet);
		// le paquet reçu (qui sera réutilisé après pour l'envoi) contient déjà
		// l'adresse du client

		String date = new GregorianCalendar().getTime().toString();

		paquet.setData(date.getBytes());

		serveur.send(paquet);

		serveur.close();

	}

	public static void main(String args[]) throws IOException {
		ServeurUdpDaytimeBis serveur = new ServeurUdpDaytimeBis(50007, 5);
		serveur.lancer();
	}

}
