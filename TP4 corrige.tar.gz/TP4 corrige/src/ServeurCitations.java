import java.io.*;
import java.net.*;
import java.util.*;

public class ServeurCitations {

	private Vector<String> tableauCitations;
	private InetAddress adrGroupe;
	private int portGroupe;
	private int pause;

	public ServeurCitations(String fichier, String adrGroupe, int portGroupe, int pause)
			throws IOException {
		tableauCitations = new Vector<String>();
		BufferedReader fichierCitations = new BufferedReader(
				new InputStreamReader(new FileInputStream(fichier)));
		String buf;

		while ((buf = fichierCitations.readLine()) != null)
			tableauCitations.add(buf);

		fichierCitations.close();

		this.adrGroupe = InetAddress.getByName(adrGroupe);
		this.portGroupe = portGroupe;
		this.pause = pause;
	}

	public void lancer() throws IOException, InterruptedException {

		DatagramSocket socketServeur = new DatagramSocket();

		DatagramPacket paquetSend;
		String msgSeveur;

		int i = 0;
		
		System.out.println("Serveur de citations lancé ");

		while (true) {

			msgSeveur = tableauCitations.get(i);
			
			paquetSend = new DatagramPacket(msgSeveur.getBytes(),
					msgSeveur.getBytes().length, adrGroupe, portGroupe);
			socketServeur.send(paquetSend);
			Thread.sleep(pause*1000);

			i++;
			if (i == tableauCitations.size())
				i = 0;

		}

		// socketServeur.close();
	}

	public static void main(String[] args) throws IOException,
			InterruptedException {
		ServeurCitations serveur = new ServeurCitations("citations.txt",
				"238.0.0.1", 2000, 4);
		serveur.lancer();
	}
}