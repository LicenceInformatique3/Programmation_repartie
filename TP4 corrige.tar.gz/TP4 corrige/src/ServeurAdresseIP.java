import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.GregorianCalendar;

public class ServeurAdresseIP {

	private int port;
	private int nbClients;

	public ServeurAdresseIP(int port, int nbClients) {
		this.port = port;
		this.nbClients = nbClients;
	}

	public void lancer() {
		byte[] buf = new byte[512];

		try {

			DatagramSocket socket = new DatagramSocket(null);
			socket.bind(new InetSocketAddress(port));

			DatagramPacket packetReceive = new DatagramPacket(buf, buf.length);

			String chaineDate;

			System.out.println("Serveur daytime lancé sur le port " + port);

			for (int i = 1; i <= nbClients; i++) {

				socket.receive(packetReceive);

				// serveur reccupère le type de requêtes et l'adresse IP dans le
				// datagrampacket envoyé par le client.

				// type de requete dans le premier octet
				String typeRequete = new String(packetReceive.getData(), 0, 1);

				// l'adresse IP dans le reste du msg
				String objetRequete = new String(packetReceive.getData(), 1,
						packetReceive.getLength() - 1);

				String reponseServeur;

				try {

					CAdresseIP adr = new CAdresseIP(objetRequete);

					switch (typeRequete) {
					case "1":
						reponseServeur = new CAdresseIP(objetRequete)
								.getClasse();
						break;
					case "2":
						reponseServeur = new CAdresseIP(objetRequete)
								.getReseau();
						break;
					case "3":
						reponseServeur = new CAdresseIP(objetRequete)
								.getBroadcast();
						break;
					default:
						reponseServeur = "Erreur";
						break;

					}

				} catch (Exception e) {
					reponseServeur = "Adrresse IP non valide";
				}

				DatagramPacket packetSend = new DatagramPacket(
						reponseServeur.getBytes(),
						reponseServeur.getBytes().length,
						packetReceive.getAddress(), packetReceive.getPort());
				
				socket.send(packetSend);
			}

			socket.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		new ServeurAdresseIP(Integer.parseInt(args[0]),
				Integer.parseInt(args[1])).lancer();
	}

}