import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class ClientAdresseIP {

	String hostname; // le nom ou l'adresse IP sous format textuel du serveur
	// udp daytime à contacter
	int port; // le port sur lequel écoute le serveur à contacter

	String typeRequete;
	String objetRequete;

	public ClientAdresseIP(String hostname, int port, String typeRequete, String objetRequete) {
		this.hostname = hostname;
		this.port = port;

		this.typeRequete = typeRequete;

		this.objetRequete = objetRequete ;
	}

	public void lancer() throws IOException {

		DatagramSocket client = new DatagramSocket();
		
		byte[] requete = (typeRequete + objetRequete).getBytes();

		DatagramPacket paquet = new DatagramPacket(requete, requete.length,
				InetAddress.getByName(hostname), port);

		// On envoie la requete : type + objet

		client.send(paquet);
		
		byte []reponse = new byte[512];
		
		DatagramPacket paquetReceive = new DatagramPacket(reponse, reponse.length);
		
		client.receive(paquetReceive);
		
		System.out.println(new String(paquetReceive.getData(), 0, paquetReceive.getLength()));

				client.close();

	}

	public static void main(String[] args) throws IOException {
		ClientAdresseIP client = new ClientAdresseIP("localhost", 50008,"1","192.124.187.29");
		client.lancer();
	}

}