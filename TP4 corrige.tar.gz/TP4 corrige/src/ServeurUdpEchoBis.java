import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.util.GregorianCalendar;


public class ServeurUdpEchoBis {
	
	int port;
	int nbClients;
	
	public ServeurUdpEchoBis(int port, int nbClients){
		this.port = port;
		this.nbClients = nbClients;
	}
	
	public void lancer() throws IOException{
		DatagramSocket serveur = new DatagramSocket(port);
		
		byte[] buf = new byte[50];
		DatagramPacket paquet = new DatagramPacket(buf, buf.length);
		
		
		while(true){
		serveur.receive(paquet);
		
		String msg = new String(paquet.getData(), 0, paquet.getLength());
		
		msg = msg.toUpperCase();
		
		paquet.setData(msg.getBytes());
		
		serveur.send(paquet);
		
		}
		
		
		
		
	}
	
	public static void main (String args[]) throws IOException{
		ServeurUdpEchoBis serveur = new ServeurUdpEchoBis(50007,5);
		serveur.lancer();
	}

}
