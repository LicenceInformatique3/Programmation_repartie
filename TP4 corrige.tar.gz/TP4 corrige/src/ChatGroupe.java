import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

import javax.swing.SwingUtilities;

public class ChatGroupe {

	InetAddress adrGroupe;
	int portGroupe;
	MulticastSocket socket;
	FenetreChat f;
	boolean actif;

	public ChatGroupe(InetAddress adrGroupe, int portGroupe) {
		this.adrGroupe = adrGroupe;
		this.portGroupe = portGroupe;

	}

	public void lancerChatGroup() throws IOException {

		socket = new MulticastSocket(portGroupe);
		socket.joinGroup(adrGroupe);

		actif = true;

		f = new FenetreChat("Chat en groupe");
		f.capturerEntree(new ActionListenerChatGroupe());

		f.gererFermeture(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				try {
					socket.leaveGroup(adrGroupe);
					actif = false;
					socket.close();
					System.exit(0);

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}

		});

		new ThreadReception().start();
		// meme si on appelle recevoirMessages() en dehors du thread, ça marche
		// car il y'a un autre thread pour l'interface graphique
		// Il s'agit de l'EDT : Event Dispatch Thread
	}

	// Le KeyAdapter associé au fait de taper entrée est défini comme une classe
	// Inner (classe imbriquée) pour accéder
	// directement à la MulticastSocket et à la FenetreChat de cette classe
	// Si on le définit en dehors de cette classe, on doit les lui passer
	// comme paramètres

	// On peut aussi la défrinir comme classe anonyme.

	class ActionListenerChatGroupe implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			try {

				envoyerMessage(f.getMessage());
				// si l'envoi est lent, l'interface graphique sera figée car ce
				// send() s'execute dans le thread EDT
				// Sinon on utilise Swingworker

			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}

	}

	// Le Thread suivant est défini comme une classe Inner (classe imbriquée)
	// pour pouvoir accéder
	// directement à la MulticastSocket et à la FenetreChat de cette classe
	// Si on le définit en dehors de cette classe, on doit les lui passer
	// comme paramètres

	public class ThreadReception extends Thread {
		public void run() {
			recevoirMessages();

		}
	}

	public void envoyerMessage(String msg) throws IOException {
		DatagramPacket paquetSend = new DatagramPacket(msg.getBytes(),
				msg.getBytes().length, adrGroupe, portGroupe);
		socket.send(paquetSend);
		f.effacerChampEnvoi();
	}

	public void recevoirMessages() {
		byte buf[] = new byte[512];
		String msgRecu;
		DatagramPacket paquetReceive = new DatagramPacket(buf, buf.length);

		while (actif) {
			try {
				socket.receive(paquetReceive);
				msgRecu = new String(paquetReceive.getData(), 0,
						paquetReceive.getLength());
				f.afficherMessage(msgRecu);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				// System.out.println("socket fermée");
			}

		}
	}

	public static void main(String args[]) throws IOException {

		ChatGroupe pgmeChat = new ChatGroupe(
				InetAddress.getByName("237.0.0.1"), 50000);
		pgmeChat.lancerChatGroup();

	}

}
