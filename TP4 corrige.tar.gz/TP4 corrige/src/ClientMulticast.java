import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.UnknownHostException;

public class ClientMulticast {

	/**
	 * @param args
	 */

	InetAddress groupe; // l'adresse du groupe multicast qui va recevoir les
	// messages du serveur.
	int port; // le port du groupe multicast de ce client

	public ClientMulticast(InetAddress groupe, int port) {
		// groupe doit être une adresse multicast.
		this.groupe = groupe;
		this.port = port;
	}

	public void lancer() throws IOException {

		// le groupe multicast écoute sur un port
		MulticastSocket socket = new MulticastSocket(port);

		// groupe doit être une adresse multicast.
		socket.joinGroup(groupe);

		byte buf[] = new byte[600];
		DatagramPacket packet = new DatagramPacket(buf, buf.length);

		while (true) {
			socket.receive(packet);
			System.out.println(new String(packet.getData(), 0, packet
					.getLength()));
		}

		// socket.leaveGroup(groupe);
		// socket.close();

	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		new ClientMulticast(InetAddress.getByName("238.0.0.1"), 2000)
				.lancer();

	}

}