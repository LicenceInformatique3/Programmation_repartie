import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class ClientUdpDaytimePetitBuffer {

	String hostname; // le nom ou l'adresse IP sous format textuel du serveur
	// udp daytime à contacter
	int port; // le port sur lequel écoute le serveur à contacter

	public ClientUdpDaytimePetitBuffer(String hostname, int port) {
		this.hostname = hostname;
		this.port = port;
	}

	public void lancer() throws IOException {

		DatagramSocket client = new DatagramSocket();

		byte[] buf = new byte[10];

		DatagramPacket paquet = new DatagramPacket(buf, buf.length,
				InetAddress.getByName(hostname), port);

		// on envoie un message vide juste pour que le serveur ait l'adresse de
		// la socket du client.

		client.send(paquet);

		client.receive(paquet);

		String date = new String(paquet.getData(), 0, paquet.getLength());

		System.out.println(date);

		// Le deuxième receive ne vas pas lire la suite du message précédent
		// On s'attend à un nouveau message.
		// Pour Daytime, il sera bloquant (à moins que le serveur fasse deux
		// send !)

		client.receive(paquet);
		
		date = new String(paquet.getData(), 0, paquet.getLength());
		System.out.println(date);

		client.close();

	}

	public static void main(String[] args) throws IOException {
		ClientUdpDaytimePetitBuffer client = new ClientUdpDaytimePetitBuffer("localhost", 50013);
		client.lancer();
	}

}