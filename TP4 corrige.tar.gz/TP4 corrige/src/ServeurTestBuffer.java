import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.util.GregorianCalendar;

public class ServeurTestBuffer {

	private int port;
	private int nbClients;

	public ServeurTestBuffer(int port, int nbClients) {
		this.port = port;
		this.nbClients = nbClients;
	}

	public void lancer() {
		
		//65507 : maximum qui marche
		// au dessus : java.io.IOException: Message trop long
		
		
		byte[] buf = new byte[65507];

		try {

			DatagramSocket socket = new DatagramSocket(null);
			socket.bind(new InetSocketAddress(port));

			System.out.println("la taille du buffer est " + socket.getReceiveBufferSize());

			DatagramPacket packetReceive = new DatagramPacket(buf, buf.length);


			for (int i = 1; i <= nbClients; i++) {
				System.out.println("clien à recevoi");

				socket.receive(packetReceive);
				System.out.println("clien reçu");

				int j ; 
				for ( j=0; j<buf.length-1; j++)
					
					buf[j] = 'S';
				buf[j] = 'E';

				DatagramPacket packetSend = new DatagramPacket(
					buf, buf.length,
						packetReceive.getAddress(), packetReceive.getPort());

				socket.send(packetSend);

			}

			socket.close();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) {

		//new ServeurUdpdaytimetest(Integer.parseInt(args[0]),
				//Integer.parseInt(args[1])).lancer();
		
		new ServeurTestBuffer(50001,100).lancer();
		
		// faire deux send () et bloquer le client sur une pause et faire deux recieve après
	}

}