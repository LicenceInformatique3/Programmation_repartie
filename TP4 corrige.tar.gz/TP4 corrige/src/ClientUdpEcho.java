import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class ClientUdpEcho {

	String hostname;
	int port;

	public ClientUdpEcho(String hostname, int port) {
		this.hostname = hostname;
		this.port = port;

	}

	public void lancer() {
		try {
			DatagramSocket soc = new DatagramSocket();

			byte[] buf = new byte[256];

			// On définit un BufferedReader pour saisir, depuis le clavier, la
			// chaine à envoyer au serveur.
			BufferedReader clavier = new BufferedReader(new InputStreamReader(
					System.in));

			// initialement, on définit uniquement le port et l'adresse IP du
			// serveur
			// la chaine sera définie dans la boucle

			DatagramPacket paquetSend = new DatagramPacket(buf, buf.length,
					InetAddress.getByName(hostname), port);

			DatagramPacket paquetReceive = new DatagramPacket(buf, buf.length);

			String chaineEnvoyé;

			String chaineReçue;

			while (true) {
				// on fait une lecture d'une chaine depuis le clavier et on
				// reccupère le tableau d'octets associé
				chaineEnvoyé = clavier.readLine();
				buf = chaineEnvoyé.getBytes();

				// On modifie uniquement les données à envoyer
				// l'adresse IP et le port restent les mêmes.
				paquetSend.setData(buf);

				// On envoie le DatagramPacket.
				soc.send(paquetSend);

				soc.receive(paquetReceive);

				chaineReçue = new String(paquetReceive.getData(), 0,
						paquetReceive.getLength());
				System.out.println(chaineReçue);

				// On aurait pu utiliser un seul datagram packet pour l'émission
				// et pour la reception.

				// si l'utilisateur saisit quit, le processus s'arrete
				if (chaineEnvoyé.equals("quit"))
					break;

			}
			clavier.close();
			soc.close();

		} catch (SocketException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws IOException {

		// on teste avec le serveur echo d'allegro qui écoute sur le port 7
		//ClientUdpEcho c = new ClientUdpEcho("allegro", 7);

		// On teste avec le serveur echo qui écoute sur le port 50007 en local
		 ClientUdpEcho c = new ClientUdpEcho("localhost", 50007);

		c.lancer();

	}

}