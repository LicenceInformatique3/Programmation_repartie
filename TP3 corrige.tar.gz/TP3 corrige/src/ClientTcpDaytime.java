import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientTcpDaytime {

	String hostname;
	int port;

	public ClientTcpDaytime(String hostname, int port) {
		this.hostname = hostname;
		this.port = port;
	}

	public void lancerBR() throws IOException {
		Socket s = new Socket(hostname, port);

		String ligne;

		BufferedReader br = new BufferedReader(new InputStreamReader(s
				.getInputStream()));

		// Le serveur envoie la date et l'heure sur une seule ligne=> pas besoin de boucle
		ligne = br.readLine();

		System.out.println(ligne);
		br.close();
		s.close();

	}

		public static void main(String[] args) throws IOException {

		ClientTcpDaytime c = new ClientTcpDaytime("localhost", 50013);

		//ClientTcpDaytime c = new ClientTcpDaytime("allegro", 13);

		c.lancerBR();
		

	}

};