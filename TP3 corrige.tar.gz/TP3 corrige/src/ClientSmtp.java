import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Enumeration;

public class ClientSmtp {

	String serveurSmtp;
	int port;
	String hostname; // l'adresse IP (sous format text) ou le nom de la machine

	// de l'émetteur de l'email qu'on utilise pour la
	// commande ehlo

	public ClientSmtp(String serveSmtp, int port, String hostname) {
		this.serveurSmtp = serveSmtp;
		this.port = port;
		this.hostname = hostname;

	}

	public boolean send(String from, String to, String subject, String body) {

		try {

			Socket client = new Socket(serveurSmtp, port);

			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(
					client.getOutputStream()));

			BufferedReader in = new BufferedReader(new InputStreamReader(client
					.getInputStream()));

			out.write("ehlo " + hostname + " \n");
			out.flush();

			// On analyse les lignes envoyées par le serveur
			// En cas d'erreur, on quitte
			if (analyserReponseServeur(in) == false)
				return false;

			out.write("mail from:<" + from + ">");
			out.newLine();
			out.flush();
			if (analyserReponseServeur(in) == false)
				return false;

			out.write("rcpt to:<" + to + ">\n");
			out.flush();
			if (analyserReponseServeur(in) == false)
				return false;

			out.write("data\n");
			out.flush();
			if (analyserReponseServeur(in) == false)
				return false;

			out.write("subject: " + subject + "\n");
			out.flush();

			out.write(body + "\n");
			out.flush();

			out.write(".\n");
			out.flush();

			if (analyserReponseServeur(in) == false)
				return false;

			out.write("quit \n");
			out.flush();
			if (analyserReponseServeur(in) == false)
				return false;

			out.close();

			client.close();

		} catch (UnknownHostException e) {
			e.printStackTrace();
			return false;

		} catch (IOException e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}

	public boolean analyserReponseServeur(BufferedReader in) throws IOException {

		String reponseSeveur;

		// aller jusqu'à la dernière ligne d'une réponse
		while (true) {
			reponseSeveur = in.readLine();
			if (reponseSeveur.charAt(3) != '-')
				break;
		}

		// analyser le code de la dernière ligne pour voir si c'est un message
		// d'erreur ou pas
		if (reponseSeveur.charAt(0) == '4' || reponseSeveur.charAt(0) == '5') {
			System.out.println(reponseSeveur);
			return false;
		}

		return true;

	}


}
