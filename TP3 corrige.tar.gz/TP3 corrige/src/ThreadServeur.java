import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

public class ThreadServeur extends Thread {

	Socket client;

	public ThreadServeur(Socket client) {
		this.client = client;
	}

	public void run() {
		
		String chaine;

		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream()));
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
			
			// Tant que le client est connecté 
			while ((chaine = in.readLine()) != null) {

				out.write(chaine.toUpperCase());
				out.newLine();
				out.flush();
			}
			
			out.close();
			in.close();
			client.close(); 
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
	}

}