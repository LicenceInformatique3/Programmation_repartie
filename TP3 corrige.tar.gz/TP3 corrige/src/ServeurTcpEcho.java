import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class ServeurTcpEcho {

	/**
	 * @param args
	 */
	int port;
	int nbClients;

	public ServeurTcpEcho( int port, int nbClients) {
		this.port = port;
		this.nbClients = nbClients;

	}

	public void lancer() throws IOException {
		Socket client ;
		BufferedWriter out;
		BufferedReader in;
		String chaine;


		
			ServerSocket serveur = new ServerSocket(port);

			for (int i = 1; i <= nbClients; i++) {

				client = serveur.accept();
				in = new BufferedReader(new InputStreamReader(
						client.getInputStream()));
				out = new BufferedWriter(new OutputStreamWriter(
						client.getOutputStream()));

				// tant que le client est connecté (et donc peut envoyer des
				// messages)
				while ((chaine = in.readLine()) != null) {

					out.write(chaine.toUpperCase());
					out.newLine();
					out.flush();

				}
				out.close();
				client.close();
			}

			serveur.close();


	}

	public static void main(String[] args) throws IOException {

		ServeurTcpEcho serveur = new ServeurTcpEcho( 50007, 100);
		serveur.lancer();

	}

}