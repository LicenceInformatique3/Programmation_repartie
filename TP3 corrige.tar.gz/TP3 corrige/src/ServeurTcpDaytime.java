import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.GregorianCalendar;

public class ServeurTcpDaytime {

	/**
	 * (
	 * 
	 * @param args
	 */
	int port;
	int nbClients; // nombre de client à traiter

	public ServeurTcpDaytime(int port, int nbClients) {
		this.port = port;
		this.nbClients = nbClients;

	}

	public void lancer() throws IOException {
		Socket client;
		BufferedWriter out;

		ServerSocket serveur = new ServerSocket(port);

		for (int i = 1; i <= nbClients; i++) {
			client = serveur.accept();
			out = new BufferedWriter(new OutputStreamWriter(client
					.getOutputStream()));

			// chaineDate contient la date et l'heure.
			String chaineDate = new GregorianCalendar().getTime().toString();

			out.write(chaineDate);
			out.newLine();
			out.close(); // close après un writepurge aussi => pas besoin de
							// flush ici
			client.close();
		}

		serveur.close(); // fermer la socket du serveur.

	}

	public static void main(String[] args) throws IOException {

		ServeurTcpDaytime serveur = new ServeurTcpDaytime(50013, 3);
		serveur.lancer();

	}

}