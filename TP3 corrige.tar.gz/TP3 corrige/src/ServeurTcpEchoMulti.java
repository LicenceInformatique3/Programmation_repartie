import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ServeurTcpEchoMulti {

	/**
	 * @param args
	 */
	int port;
	int nbClients;

	public ServeurTcpEchoMulti(int port, int nbClients) {
		this.port = port;
		this.nbClients = nbClients;

	}

	public void lancer() throws IOException {
		

		ServerSocket serveur = new ServerSocket(port);
		
		Socket client;


		for (int i = 1; i <= nbClients; i++) {
			client = serveur.accept();
			ThreadServeur thread = new ThreadServeur(client);
			thread.start();

		}

		serveur.close();

	}

	public static void main(String[] args) throws IOException {

		ServeurTcpEchoMulti serveur = new ServeurTcpEchoMulti(50007,3);
		serveur.lancer();

	}

}