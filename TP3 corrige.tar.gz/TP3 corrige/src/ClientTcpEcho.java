import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class ClientTcpEcho {

	String hostname;
	int port;

	public ClientTcpEcho(String hostname, int port) {
		this.hostname = hostname;
		this.port = port;
	}

	public void lancerBW() throws UnknownHostException, IOException {

		Socket soc = new Socket(hostname, port);
		String bufSend;
		String bufReceived;

		BufferedReader clavier = new BufferedReader(new InputStreamReader(
				System.in));

		BufferedWriter out = new BufferedWriter(new OutputStreamWriter(soc
				.getOutputStream()));

		BufferedReader in = new BufferedReader(new InputStreamReader(soc
				.getInputStream()));

		while (true) {

			bufSend = clavier.readLine();

			if (bufSend.equals("quit"))

				break;
			else {
				out.write(bufSend);
				// rajouter un saut de ligne pour pouvoir utiliser readline par
				// la suite
				out.newLine();
				// vider le buffer
				out.flush();
				// lire la chaine envoyée par le serveur
				bufReceived = in.readLine();
				System.out.println(bufReceived);
			}

		}
		in.close();
		out.close();
		soc.close();

	}

	public static void main(String[] args) throws UnknownHostException,
			IOException {
		
		//ClientTcpEcho client = new ClientTcpEcho("allegro", 7);
		
		
		ClientTcpEcho client = new ClientTcpEcho("localhost", 50007);


		client.lancerBW();

	}

}