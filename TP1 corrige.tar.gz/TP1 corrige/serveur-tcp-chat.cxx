#include "mesfonctions.h"


int main() {

	int sock_serveur = socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in sockaddr_serveur;

	sockaddr_serveur.sin_family = AF_INET;
	sockaddr_serveur.sin_port = htons(NUM_PORT);
	sockaddr_serveur.sin_addr.s_addr = htonl(INADDR_ANY);

	int yes = 1;
	if (setsockopt(sock_serveur, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int))
			== -1)
		exitErreur("setsockopt");

	if (bind(sock_serveur, (struct sockaddr *) &sockaddr_serveur,
			sizeof(sockaddr_in)) == -1)
		exitErreur("bind");

	if (listen(sock_serveur, BACKLOG) == -1)
		exitErreur("listen");

	int sock_client;


	string msgClavier;
	string msgRecu("");

	int n;

	cout << "Serveur chat lancé  sur le port " << NUM_PORT << endl;

	for (int i = 1; i <= NB_CLIENTS; i++) {

		// Le serveur attend un client
		sock_client = accept(sock_serveur, NULL, NULL);
		if (sock_client == -1)
			exitErreur("accept");

		// Le serveur chatte à tour de rôle avec le client
		// Le client commence, ça se termine lorsque le client envoie bye ou il y a deconnexion

		for (;;) {

			// lire le message du client qui doit se terminer par un saut de ligne

			n = readLine(sock_client,msgRecu);
			
			// client s'est déconnecté
			if (!n ) break ;
			
			cout << "Toi : " << msgRecu ;

			// client envoie bye

			
			//utiliser "if (msgRecu == "bye\r\n")" si on teste le serveur depuis telnet
			
			if (msgRecu == "bye\n")
				break;
				
			// le message envoyé par telnet se termine par \r\n
			
			// Lire depuis le claiver un msg sous de forme de string et lui rajouter un saut de ligne

			cout << "Moi : ";
			getline(cin , msgClavier);
			msgClavier = msgClavier + '\n';
		

			// Le serveur envoie le message au client
			if (write(sock_client, msgClavier.c_str(), msgClavier.length() ) == -1)
				exitErreur("write");
		
		}

		cout << "Un autre client ? " << endl;

		close(sock_client);

	}
	close(sock_serveur);
	return 0;
}
