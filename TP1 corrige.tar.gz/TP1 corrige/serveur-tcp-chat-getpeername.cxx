#include "mesfonctions.h"
#define ADRESSE_BLACKLISTE "10.0.2.15"


int main() {

	int sock_serveur = socket(AF_INET, SOCK_STREAM, 0);

	struct sockaddr_in sockaddr_serveur;

	sockaddr_serveur.sin_family = AF_INET;
	sockaddr_serveur.sin_port = htons(NUM_PORT);
	sockaddr_serveur.sin_addr.s_addr = htonl(INADDR_ANY);

	int yes = 1;
	if (setsockopt(sock_serveur, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int))
			== -1)
		exitErreur("setsockopt");

	if (bind(sock_serveur, (struct sockaddr *) &sockaddr_serveur,
			sizeof(sockaddr_in)) == -1)
		exitErreur("bind");

	if (listen(sock_serveur, BACKLOG) == -1)
		exitErreur("listen");

	int sock_client;


	string msgClavier;
	string msgRecu("");

	int n;

	cout << "Serveur chat lancé  sur le port " << NUM_PORT << endl;
	
	struct sockaddr_in sockaddr_client ; socklen_t addrlen;


	for (int i = 1; i <= NB_CLIENTS; i++) {

		// Le serveur attend un client
		addrlen = sizeof(struct sockaddr_in);

		sock_client = accept(sock_serveur, (struct sockaddr *) &sockaddr_client, & addrlen);       

		if (sock_client == -1)
			exitErreur("accept");
			
		// deuxième possibilité pour avoir adresse et port du client
		//getpeername(sock_client, (struct sockaddr * ) &sockaddr_client, & addrlen); 

		cout << "Connexion de " << inet_ntoa(sockaddr_client.sin_addr) <<":"<< ntohs(sockaddr_client.sin_port) << endl;
			
		if (!strcmp( inet_ntoa(sockaddr_client.sin_addr), ADRESSE_BLACKLISTE)) {
			cout << "adresse interdite "<< endl; 
			close(sock_client); 
			continue;
		}


		// Le serveur chatte à tour de rôle avec le client
		// Le client commence, ça se termine lorsque le client envoie bye ou il y a deconnexion

		for (;;) {

			// lire le message du client qui doit se terminer par un saut de ligne

			cout << "lire" << endl;
			n = readLine(sock_client,msgRecu);
			
			// client s'est déconnecté
			if (!n ) break ;
			
			if (n==-1) exitErreur("readLine");
			
			cout << "Toi : " << msgRecu ;

			// client envoie bye

			
			//utiliser "if (msgRecu == "bye\r\n")" si on teste le serveur depuis telnet
			
			if (msgRecu == "bye\n")
				break;
				
			// le message envoyé par telnet se termine par \r\n
			
			// Lire depuis le claiver un msg sous de forme de string et lui rajouter un saut de ligne

			cout << "Moi : ";
			getline(cin , msgClavier);
			msgClavier = msgClavier + '\n';
		

			// Le serveur envoie le message au client
			if (write(sock_client, msgClavier.c_str(), msgClavier.length() ) == -1)
				exitErreur("write");
		
		}

		cout << "Un autre client ? " << endl;

		close(sock_client);

	}
	close(sock_serveur);
	return 0;
}
